package com.example.hanzireminder.data

import kotlin.random.Random

/**
 * ระบบทบทวนแบบเว้นช่วงเวลา (กล่อง 0-7)
 *  - ไม่ได้  -> กลับกล่อง 0 เจออีกใน 10 นาที
 *  - จำได้   -> ขึ้นกล่องถัดไป ช่วงห่างยาวขึ้นเรื่อยๆ (8 ชม. -> 1 -> 3 -> 7 -> 14 -> 30 วัน)
 *  - รู้แล้ว  -> กล่อง 7 ช่วงห่าง 90 วัน (นานๆ ครั้งจึงกลับมาให้ทบทวน)
 *  - คำใหม่ (ยังไม่เคยเห็น) จะถูกสุ่มมาเรื่อยๆ จนกว่าจะกดจำได้หรือรู้แล้ว
 */
object Srs {
    const val KNOWN_BOX = 7

    enum class Rating { AGAIN, GOOD, KNOWN }

    private const val MIN = 60_000L
    private const val HOUR = 60 * MIN
    private const val DAY = 24 * HOUR

    private val intervals = longArrayOf(
        10 * MIN, 8 * HOUR, 1 * DAY, 3 * DAY, 7 * DAY, 14 * DAY, 30 * DAY, 90 * DAY,
    )

    fun rate(word: Word, rating: Rating, now: Long = System.currentTimeMillis()): Word {
        val newBox = when (rating) {
            Rating.AGAIN -> 0
            Rating.GOOD ->
                if (word.box >= KNOWN_BOX) KNOWN_BOX else minOf(word.box + 1, KNOWN_BOX - 1)
            Rating.KNOWN -> KNOWN_BOX
        }
        return word.copy(
            box = newBox,
            seenCount = word.seenCount + 1,
            lastReviewed = now,
            nextDue = now + intervals[newBox],
        )
    }

    private fun weightOf(word: Word): Double = when (word.box) {
        0 -> 6.0
        1 -> 4.0
        2 -> 3.0
        3 -> 2.0
        4 -> 1.5
        5 -> 1.0
        else -> 0.8
    }

    /** เลือกคำถัดไปแบบสุ่มถ่วงน้ำหนัก: คำที่จำไม่ได้มาบ่อยสุด คำที่จำได้แล้วมาน้อยลง */
    suspend fun pickNext(
        dao: WordDao,
        excludeId: Long = -1L,
        now: Long = System.currentTimeMillis(),
    ): Word? {
        val learning = dao.dueLearning(now, excludeId, 30)
        val fresh = dao.newWords(excludeId, 5)
        val known = dao.dueKnown(now, excludeId, 5)

        val candidates = ArrayList<Pair<Word, Double>>()
        learning.forEach { candidates.add(it to weightOf(it)) }
        // ถ้ามีคำค้างทบทวนเยอะ ลดโอกาสเจอคำใหม่ลง จะได้ไม่ท่วม
        val freshWeight = if (learning.size >= 15) 0.5 else 3.0
        fresh.forEach { candidates.add(it to freshWeight) }
        known.forEach { candidates.add(it to 0.5) }

        if (candidates.isEmpty()) {
            return dao.earliest(excludeId) ?: dao.earliest(-1L)
        }
        val total = candidates.sumOf { it.second }
        var r = Random.nextDouble() * total
        for ((word, weight) in candidates) {
            r -= weight
            if (r <= 0) return word
        }
        return candidates.last().first
    }
}

package com.example.hanzireminder

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hanzireminder.data.AppDatabase
import com.example.hanzireminder.data.Repository
import com.example.hanzireminder.data.Settings
import com.example.hanzireminder.data.Srs
import com.example.hanzireminder.data.Word
import com.example.hanzireminder.reminder.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val dao = AppDatabase.get(ctx).wordDao()

    val words: StateFlow<List<Word>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _times = MutableStateFlow(Settings.times(ctx))
    val times: StateFlow<Set<String>> = _times

    // คำที่กำลังทบทวนอยู่ในการ์ดหน้าแอป
    private val _current = MutableStateFlow<Word?>(null)
    val current: StateFlow<Word?> = _current

    private val _flipped = MutableStateFlow(false)
    val flipped: StateFlow<Boolean> = _flipped

    init {
        viewModelScope.launch(Dispatchers.IO) {
            Repository.ensureSeeded(ctx)
            loadNext()
        }
        _times.value.forEach { ReminderScheduler.schedule(ctx, it) }
    }

    private suspend fun loadNext() {
        _current.value = Repository.next(ctx, _current.value?.id ?: -1L)
        _flipped.value = false
    }

    fun flip() {
        _flipped.value = !_flipped.value
    }

    fun skip() {
        viewModelScope.launch(Dispatchers.IO) { loadNext() }
    }

    fun rate(rating: Srs.Rating) {
        val word = _current.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            Repository.rate(ctx, word.id, rating)
            loadNext()
        }
    }

    fun addWord(hanzi: String, pinyin: String, meaning: String) {
        if (hanzi.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.insert(Word(hanzi = hanzi.trim(), pinyin = pinyin.trim(), meaning = meaning.trim()))
        }
    }

    fun deleteWord(word: Word) {
        viewModelScope.launch(Dispatchers.IO) { dao.delete(word) }
    }

    fun addTime(time: String) {
        val updated = _times.value + time
        Settings.setTimes(ctx, updated)
        _times.value = updated
        ReminderScheduler.schedule(ctx, time)
    }

    fun removeTime(time: String) {
        val updated = _times.value - time
        Settings.setTimes(ctx, updated)
        _times.value = updated
        ReminderScheduler.cancel(ctx, time)
    }
}

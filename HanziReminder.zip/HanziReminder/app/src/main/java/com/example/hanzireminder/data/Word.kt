package com.example.hanzireminder.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "words")
data class Word(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hanzi: String,
    val pinyin: String,
    val meaning: String,
    val isBuiltIn: Boolean = false,
    // ประโยคตัวอย่าง
    val example: String = "",
    val examplePinyin: String = "",
    val exampleMeaning: String = "",
    // ความคืบหน้าการเรียน: box 0 = ยังจำไม่ได้, 1-6 = จำได้ระดับต่างๆ, 7 = รู้แล้ว
    val box: Int = 0,
    val seenCount: Int = 0,
    val lastReviewed: Long = 0L,
    val nextDue: Long = 0L,
)

enum class Status { NEW, LEARNING, KNOWN }

fun Word.status(): Status = when {
    seenCount == 0 -> Status.NEW
    box >= Srs.KNOWN_BOX -> Status.KNOWN
    else -> Status.LEARNING
}

@Dao
interface WordDao {
    @Query("SELECT * FROM words ORDER BY id ASC")
    fun observeAll(): Flow<List<Word>>

    @Query(
        "SELECT * FROM words WHERE seenCount > 0 AND box < 7 AND nextDue <= :now " +
            "AND id != :excludeId ORDER BY nextDue ASC LIMIT :limit",
    )
    suspend fun dueLearning(now: Long, excludeId: Long, limit: Int): List<Word>

    @Query("SELECT * FROM words WHERE seenCount = 0 AND id != :excludeId ORDER BY id ASC LIMIT :limit")
    suspend fun newWords(excludeId: Long, limit: Int): List<Word>

    @Query(
        "SELECT * FROM words WHERE seenCount > 0 AND box >= 7 AND nextDue <= :now " +
            "AND id != :excludeId ORDER BY nextDue ASC LIMIT :limit",
    )
    suspend fun dueKnown(now: Long, excludeId: Long, limit: Int): List<Word>

    @Query("SELECT * FROM words WHERE id != :excludeId ORDER BY nextDue ASC LIMIT 1")
    suspend fun earliest(excludeId: Long): Word?

    @Query("SELECT * FROM words WHERE id = :id")
    suspend fun byId(id: Long): Word?

    @Query("SELECT COUNT(*) FROM words")
    suspend fun count(): Int

    @Query("DELETE FROM words WHERE isBuiltIn = 1")
    suspend fun deleteBuiltIn()

    @Insert
    suspend fun insert(word: Word): Long

    @Insert
    suspend fun insertAll(words: List<Word>)

    @Update
    suspend fun update(word: Word)

    @Delete
    suspend fun delete(word: Word)
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE words ADD COLUMN example TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE words ADD COLUMN examplePinyin TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE words ADD COLUMN exampleMeaning TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE words ADD COLUMN box INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE words ADD COLUMN seenCount INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE words ADD COLUMN lastReviewed INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE words ADD COLUMN nextDue INTEGER NOT NULL DEFAULT 0")
    }
}

@Database(entities = [Word::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "hanzi.db",
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
    }
}

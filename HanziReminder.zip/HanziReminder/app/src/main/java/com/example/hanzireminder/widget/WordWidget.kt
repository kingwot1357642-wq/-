package com.example.hanzireminder.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.state.getAppWidgetState
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.state.GlanceStateDefinition
import androidx.glance.state.PreferencesGlanceStateDefinition
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.hanzireminder.data.Repository
import com.example.hanzireminder.data.Srs

private val WID = longPreferencesKey("wid")
private val HANZI = stringPreferencesKey("hanzi")
private val PINYIN = stringPreferencesKey("pinyin")
private val MEANING = stringPreferencesKey("meaning")
private val EXAMPLE = stringPreferencesKey("example")
private val EXAMPLE_PINYIN = stringPreferencesKey("example_pinyin")
private val EXAMPLE_MEANING = stringPreferencesKey("example_meaning")
private val FLIPPED = booleanPreferencesKey("flipped")

private val RATING_KEY = ActionParameters.Key<String>("rating")

class WordWidget : GlanceAppWidget() {

    override val stateDefinition: GlanceStateDefinition<*> = PreferencesGlanceStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val prefs = getAppWidgetState(context, PreferencesGlanceStateDefinition, id)
        if (prefs[WID] == null) pickNext(context, id)
        provideContent { Content() }
    }

    @Composable
    private fun Content() {
        val prefs = currentState<Preferences>()
        val flipped = prefs[FLIPPED] ?: false
        val dark = ColorProvider(Color(0xFF212121))
        val gray = ColorProvider(Color(0xFF616161))

        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(ColorProvider(Color(0xFFFFF8E1)))
                .padding(10.dp)
                .clickable(actionRunCallback<FlipAction>()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = prefs[HANZI] ?: "…",
                style = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold, color = dark),
            )
            if (flipped) {
                Text(
                    text = prefs[PINYIN].orEmpty(),
                    style = TextStyle(fontSize = 16.sp, color = dark),
                )
                Text(
                    text = prefs[MEANING].orEmpty(),
                    style = TextStyle(fontSize = 15.sp, color = dark, textAlign = TextAlign.Center),
                    maxLines = 2,
                )
                if (!prefs[EXAMPLE].isNullOrEmpty()) {
                    Column(
                        modifier = GlanceModifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = prefs[EXAMPLE].orEmpty(),
                            style = TextStyle(fontSize = 14.sp, color = dark, textAlign = TextAlign.Center),
                            maxLines = 2,
                        )
                        Text(
                            text = prefs[EXAMPLE_PINYIN].orEmpty(),
                            style = TextStyle(fontSize = 11.sp, color = gray, textAlign = TextAlign.Center),
                            maxLines = 2,
                        )
                        Text(
                            text = prefs[EXAMPLE_MEANING].orEmpty(),
                            style = TextStyle(fontSize = 12.sp, color = gray, textAlign = TextAlign.Center),
                            maxLines = 2,
                        )
                    }
                }
                Row(
                    modifier = GlanceModifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    RateButton("ไม่ได้", Color(0xFFC62828), "again")
                    RateButton("จำได้", Color(0xFF2E7D32), "good")
                    RateButton("รู้แล้ว", Color(0xFF1565C0), "known")
                }
            } else {
                Text(
                    text = "แตะเพื่อดูคำตอบ",
                    modifier = GlanceModifier.padding(top = 6.dp),
                    style = TextStyle(fontSize = 12.sp, color = gray),
                )
                Text(
                    text = "ข้าม ▶",
                    modifier = GlanceModifier
                        .padding(top = 10.dp)
                        .clickable(actionRunCallback<SkipAction>()),
                    style = TextStyle(
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = ColorProvider(Color(0xFFB71C1C)),
                    ),
                )
            }
        }
    }

    @Composable
    private fun RateButton(label: String, color: Color, rating: String) {
        Text(
            text = label,
            modifier = GlanceModifier
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .background(ColorProvider(color))
                .clickable(actionRunCallback<RateAction>(actionParametersOf(RATING_KEY to rating))),
            style = TextStyle(
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = ColorProvider(Color.White),
                textAlign = TextAlign.Center,
            ),
        )
    }

    companion object {
        suspend fun pickNext(context: Context, id: GlanceId) {
            val current = getAppWidgetState(context, PreferencesGlanceStateDefinition, id)[WID] ?: -1L
            val word = Repository.next(context, excludeId = current) ?: return
            updateAppWidgetState(context, id) { prefs ->
                prefs[WID] = word.id
                prefs[HANZI] = word.hanzi
                prefs[PINYIN] = word.pinyin
                prefs[MEANING] = word.meaning
                prefs[EXAMPLE] = word.example
                prefs[EXAMPLE_PINYIN] = word.examplePinyin
                prefs[EXAMPLE_MEANING] = word.exampleMeaning
                prefs[FLIPPED] = false
            }
        }

        suspend fun flip(context: Context, id: GlanceId) {
            updateAppWidgetState(context, id) { prefs ->
                prefs[FLIPPED] = !(prefs[FLIPPED] ?: false)
            }
        }

        suspend fun rate(context: Context, id: GlanceId, rating: Srs.Rating) {
            val wordId = getAppWidgetState(context, PreferencesGlanceStateDefinition, id)[WID]
            if (wordId != null) Repository.rate(context, wordId, rating)
        }
    }
}

class FlipAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        WordWidget.flip(context, glanceId)
        WordWidget().update(context, glanceId)
    }
}

class SkipAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        WordWidget.pickNext(context, glanceId)
        WordWidget().update(context, glanceId)
    }
}

class RateAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val rating = when (parameters[RATING_KEY]) {
            "again" -> Srs.Rating.AGAIN
            "known" -> Srs.Rating.KNOWN
            else -> Srs.Rating.GOOD
        }
        WordWidget.rate(context, glanceId, rating)
        WordWidget.pickNext(context, glanceId)
        WordWidget().update(context, glanceId)
    }
}

class WordWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WordWidget()
}

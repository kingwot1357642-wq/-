package com.example.hanzireminder.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.state.getAppWidgetState
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.state.GlanceStateDefinition
import androidx.glance.state.PreferencesGlanceStateDefinition
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.hanzireminder.data.Repository

private val HANZI = stringPreferencesKey("hanzi")
private val PINYIN = stringPreferencesKey("pinyin")
private val MEANING = stringPreferencesKey("meaning")
private val FLIPPED = booleanPreferencesKey("flipped")

class WordWidget : GlanceAppWidget() {

    override val stateDefinition: GlanceStateDefinition<*> = PreferencesGlanceStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val prefs = getAppWidgetState(context, PreferencesGlanceStateDefinition, id)
        if (prefs[HANZI] == null) pickNext(context, id)
        provideContent { Content() }
    }

    @Composable
    private fun Content() {
        val prefs = currentState<Preferences>()
        val flipped = prefs[FLIPPED] ?: false
        val dark = ColorProvider(Color(0xFF212121))
        val gray = ColorProvider(Color(0xFF616161))

        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(ColorProvider(Color(0xFFFFF8E1)))
                .padding(12.dp)
                .clickable(actionRunCallback<FlipAction>()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = prefs[HANZI] ?: "…",
                style = TextStyle(fontSize = 38.sp, fontWeight = FontWeight.Bold, color = dark),
            )
            if (flipped) {
                Text(
                    text = prefs[PINYIN].orEmpty(),
                    style = TextStyle(fontSize = 16.sp, color = dark),
                )
                Text(
                    text = prefs[MEANING].orEmpty(),
                    style = TextStyle(fontSize = 16.sp, color = dark),
                )
            } else {
                Text(
                    text = "แตะเพื่อดูคำตอบ",
                    style = TextStyle(fontSize = 12.sp, color = gray),
                )
            }
            Text(
                text = "ถัดไป ▶",
                modifier = GlanceModifier
                    .padding(top = 8.dp)
                    .clickable(actionRunCallback<NextAction>()),
                style = TextStyle(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = ColorProvider(Color(0xFFB71C1C)),
                    textAlign = TextAlign.Center,
                ),
            )
        }
    }

    companion object {
        suspend fun pickNext(context: Context, id: GlanceId) {
            val word = Repository.random(context) ?: return
            updateAppWidgetState(context, id) { prefs ->
                prefs[HANZI] = word.hanzi
                prefs[PINYIN] = word.pinyin
                prefs[MEANING] = word.meaning
                prefs[FLIPPED] = false
            }
        }

        suspend fun flip(context: Context, id: GlanceId) {
            updateAppWidgetState(context, id) { prefs ->
                prefs[FLIPPED] = !(prefs[FLIPPED] ?: false)
            }
        }
    }
}

class FlipAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: androidx.glance.action.ActionParameters) {
        WordWidget.flip(context, glanceId)
        WordWidget().update(context, glanceId)
    }
}

class NextAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: androidx.glance.action.ActionParameters) {
        WordWidget.pickNext(context, glanceId)
        WordWidget().update(context, glanceId)
    }
}

class WordWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WordWidget()
}

package com.example.hanzireminder.data

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray

object Repository {
    private val mutex = Mutex()
    private const val PREFS = "data"
    private const val KEY_SEED = "seed_version"
    private const val SEED_VERSION = 2 // 2 = HSK 3.0 ระดับ 1 (300 คำ) พร้อมประโยคตัวอย่าง

    private fun dao(context: Context) = AppDatabase.get(context).wordDao()

    private suspend fun seedLocked(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getInt(KEY_SEED, 0) >= SEED_VERSION) return

        val json = context.assets.open("hsk1.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONArray(json)
        val words = ArrayList<Word>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            words.add(
                Word(
                    hanzi = o.getString("h"),
                    pinyin = o.getString("p"),
                    meaning = o.getString("m"),
                    isBuiltIn = true,
                    example = o.getString("e"),
                    examplePinyin = o.getString("ep"),
                    exampleMeaning = o.getString("et"),
                ),
            )
        }
        val d = dao(context)
        d.deleteBuiltIn() // ลบชุดเริ่มต้นเก่า (12 คำ) คำที่ผู้ใช้เพิ่มเองยังอยู่
        d.insertAll(words)
        prefs.edit().putInt(KEY_SEED, SEED_VERSION).apply()
    }

    suspend fun ensureSeeded(context: Context) = mutex.withLock { seedLocked(context) }

    /** สุ่มคำถัดไปตามระบบทบทวน (ไม่ซ้ำกับ excludeId) */
    suspend fun next(context: Context, excludeId: Long = -1L): Word? = mutex.withLock {
        seedLocked(context)
        Srs.pickNext(dao(context), excludeId)
    }

    suspend fun rate(context: Context, wordId: Long, rating: Srs.Rating) {
        mutex.withLock {
            val d = dao(context)
            val word = d.byId(wordId) ?: return@withLock
            d.update(Srs.rate(word, rating))
        }
    }
}

object Settings {
    private const val PREFS = "settings"
    private const val KEY_TIMES = "reminder_times"
    private val defaultTimes = setOf("08:00", "20:00")

    fun times(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_TIMES, defaultTimes) ?: defaultTimes

    fun setTimes(context: Context, times: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_TIMES, times).apply()
    }
}

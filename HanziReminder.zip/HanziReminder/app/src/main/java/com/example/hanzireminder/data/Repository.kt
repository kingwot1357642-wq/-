package com.example.hanzireminder.data

import android.content.Context

object BuiltInWords {
    // ชุดเริ่มต้นสั้น ๆ (HSK 1) — เพิ่มได้เองตามต้องการ หรือย้ายไปเป็นไฟล์ JSON ใน assets ภายหลัง
    val list = listOf(
        Word(hanzi = "你好", pinyin = "nǐ hǎo", meaning = "สวัสดี", isBuiltIn = true),
        Word(hanzi = "谢谢", pinyin = "xièxie", meaning = "ขอบคุณ", isBuiltIn = true),
        Word(hanzi = "再见", pinyin = "zàijiàn", meaning = "ลาก่อน", isBuiltIn = true),
        Word(hanzi = "对不起", pinyin = "duìbuqǐ", meaning = "ขอโทษ", isBuiltIn = true),
        Word(hanzi = "我", pinyin = "wǒ", meaning = "ฉัน", isBuiltIn = true),
        Word(hanzi = "你", pinyin = "nǐ", meaning = "คุณ", isBuiltIn = true),
        Word(hanzi = "爱", pinyin = "ài", meaning = "รัก", isBuiltIn = true),
        Word(hanzi = "水", pinyin = "shuǐ", meaning = "น้ำ", isBuiltIn = true),
        Word(hanzi = "吃", pinyin = "chī", meaning = "กิน", isBuiltIn = true),
        Word(hanzi = "喝", pinyin = "hē", meaning = "ดื่ม", isBuiltIn = true),
        Word(hanzi = "学习", pinyin = "xuéxí", meaning = "เรียน", isBuiltIn = true),
        Word(hanzi = "朋友", pinyin = "péngyou", meaning = "เพื่อน", isBuiltIn = true),
    )
}

object Repository {
    suspend fun seedIfEmpty(dao: WordDao) {
        if (dao.count() == 0) dao.insertAll(BuiltInWords.list)
    }

    suspend fun random(context: Context): Word? {
        val dao = AppDatabase.get(context).wordDao()
        seedIfEmpty(dao)
        return dao.random()
    }
}

object Settings {
    private const val PREFS = "settings"
    private const val KEY_TIMES = "reminder_times"
    private val defaultTimes = setOf("08:00", "20:00")

    fun times(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_TIMES, defaultTimes) ?: defaultTimes

    fun setTimes(context: Context, times: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_TIMES, times).apply()
    }
}

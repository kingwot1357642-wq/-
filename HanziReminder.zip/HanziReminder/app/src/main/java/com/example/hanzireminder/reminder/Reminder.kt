package com.example.hanzireminder.reminder

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.hanzireminder.MainActivity
import com.example.hanzireminder.data.Repository
import com.example.hanzireminder.data.Word
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object ReminderScheduler {
    private fun workName(time: String) = "reminder_$time"

    /** time รูปแบบ "HH:mm" — แจ้งเตือนทุกวันตามเวลานี้ (WorkManager อาจคลาดเคลื่อนได้เล็กน้อย) */
    fun schedule(
        context: Context,
        time: String,
        policy: ExistingWorkPolicy = ExistingWorkPolicy.KEEP,
    ) {
        val (h, m) = time.split(":").map { it.toInt() }
        val now = LocalDateTime.now()
        var next = now.withHour(h).withMinute(m).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delayMs = Duration.between(now, next).toMillis()

        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("time" to time))
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(workName(time), policy, request)
    }

    fun cancel(context: Context, time: String) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(time))
    }
}

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val time = inputData.getString("time") ?: return Result.failure()
        Repository.random(applicationContext)?.let { Notifier.show(applicationContext, it) }
        // ตั้งเวลาของวันถัดไป
        ReminderScheduler.schedule(applicationContext, time, ExistingWorkPolicy.APPEND_OR_REPLACE)
        return Result.success()
    }
}

object Notifier {
    private const val CHANNEL = "review"

    @SuppressLint("MissingPermission")
    fun show(context: Context, word: Word) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val nm = NotificationManagerCompat.from(context)
        nm.createNotificationChannel(
            NotificationChannelCompat.Builder(CHANNEL, NotificationManagerCompat.IMPORTANCE_DEFAULT)
                .setName("ทบทวนคำศัพท์")
                .build(),
        )
        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("${word.hanzi}  ${word.pinyin}")
            .setContentText(word.meaning)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(word.id.toInt(), notification)
    }
}

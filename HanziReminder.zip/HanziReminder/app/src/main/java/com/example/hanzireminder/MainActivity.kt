package com.example.hanzireminder

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel = viewModel()) {
    val words by vm.words.collectAsStateWithLifecycle()
    val times by vm.times.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    var hanzi by remember { mutableStateOf("") }
    var pinyin by remember { mutableStateOf("") }
    var meaning by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("学中文 Reminder") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Text("เวลาแจ้งเตือนทุกวัน", style = MaterialTheme.typography.titleMedium) }
            items(times.sorted(), key = { it }) { t ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(t, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    TextButton(onClick = { vm.removeTime(t) }) { Text("ลบ") }
                }
            }
            item {
                Button(onClick = {
                    TimePickerDialog(
                        ctx,
                        { _, h, m -> vm.addTime("%02d:%02d".format(h, m)) },
                        8, 0, true,
                    ).show()
                }) { Text("+ เพิ่มเวลา") }
            }

            item { Text("เพิ่มคำศัพท์", style = MaterialTheme.typography.titleMedium) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(hanzi, { hanzi = it }, label = { Text("ตัวอักษรจีน") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(pinyin, { pinyin = it }, label = { Text("พินอิน") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(meaning, { meaning = it }, label = { Text("ความหมาย") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        vm.addWord(hanzi, pinyin, meaning)
                        hanzi = ""; pinyin = ""; meaning = ""
                    }) { Text("บันทึกคำ") }
                }
            }

            item { Text("คำศัพท์ทั้งหมด (${words.size})", style = MaterialTheme.typography.titleMedium) }
            items(words, key = { it.id }) { w ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${w.hanzi}  ${w.pinyin}", style = MaterialTheme.typography.bodyLarge)
                        Text(w.meaning, style = MaterialTheme.typography.bodyMedium)
                    }
                    TextButton(onClick = { vm.deleteWord(w) }) { Text("ลบ") }
                }
            }
        }
    }
}

package com.example.hanzireminder

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.hanzireminder.data.Srs
import com.example.hanzireminder.data.Status
import com.example.hanzireminder.data.Word
import com.example.hanzireminder.data.status

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

private fun statusLabel(s: Status) = when (s) {
    Status.NEW -> "ใหม่"
    Status.LEARNING -> "กำลังเรียน"
    Status.KNOWN -> "รู้แล้ว"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel = viewModel()) {
    val words by vm.words.collectAsStateWithLifecycle()
    val times by vm.times.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()
    val flipped by vm.flipped.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    var hanzi by remember { mutableStateOf("") }
    var pinyin by remember { mutableStateOf("") }
    var meaning by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) } // 0 ทั้งหมด 1 ใหม่ 2 กำลังเรียน 3 รู้แล้ว
    var expandedId by remember { mutableStateOf(-1L) }

    val newCount = words.count { it.status() == Status.NEW }
    val learningCount = words.count { it.status() == Status.LEARNING }
    val knownCount = words.count { it.status() == Status.KNOWN }

    val shown = remember(words, filter) {
        words.filter {
            when (filter) {
                1 -> it.status() == Status.NEW
                2 -> it.status() == Status.LEARNING
                3 -> it.status() == Status.KNOWN
                else -> true
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("学中文 Reminder") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // ---------- การ์ดทบทวน ----------
            item { Text("ทบทวนตอนนี้", style = MaterialTheme.typography.titleMedium) }
            item {
                val w = current
                if (w == null) {
                    Text("กำลังโหลดคำศัพท์...")
                } else {
                    ReviewCard(
                        word = w,
                        flipped = flipped,
                        onFlip = { vm.flip() },
                        onRate = { vm.rate(it) },
                        onSkip = { vm.skip() },
                    )
                }
            }

            // ---------- สถิติ ----------
            item {
                Text(
                    "ใหม่ $newCount  ·  กำลังเรียน $learningCount  ·  รู้แล้ว $knownCount  (ทั้งหมด ${words.size})",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }

            // ---------- เวลาแจ้งเตือน ----------
            item { Text("เวลาแจ้งเตือนทุกวัน", style = MaterialTheme.typography.titleMedium) }
            items(times.sorted(), key = { "t$it" }) { t ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(t, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    TextButton(onClick = { vm.removeTime(t) }) { Text("ลบ") }
                }
            }
            item {
                Button(onClick = {
                    TimePickerDialog(
                        ctx,
                        { _, h, m -> vm.addTime("%02d:%02d".format(h, m)) },
                        8, 0, true,
                    ).show()
                }) { Text("+ เพิ่มเวลา") }
            }

            // ---------- เพิ่มคำเอง ----------
            item { Text("เพิ่มคำศัพท์เอง", style = MaterialTheme.typography.titleMedium) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(hanzi, { hanzi = it }, label = { Text("ตัวอักษรจีน") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(pinyin, { pinyin = it }, label = { Text("พินอิน") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(meaning, { meaning = it }, label = { Text("ความหมาย") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        vm.addWord(hanzi, pinyin, meaning)
                        hanzi = ""; pinyin = ""; meaning = ""
                    }) { Text("บันทึกคำ") }
                }
            }

            // ---------- รายการคำ ----------
            item { Text("คำศัพท์ (${shown.size})", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = filter == 0, onClick = { filter = 0 }, label = { Text("ทั้งหมด") })
                    FilterChip(selected = filter == 1, onClick = { filter = 1 }, label = { Text("ใหม่") })
                    FilterChip(selected = filter == 2, onClick = { filter = 2 }, label = { Text("กำลังเรียน") })
                    FilterChip(selected = filter == 3, onClick = { filter = 3 }, label = { Text("รู้แล้ว") })
                }
            }
            items(shown, key = { it.id }) { w ->
                WordRow(
                    word = w,
                    expanded = expandedId == w.id,
                    onToggle = { expandedId = if (expandedId == w.id) -1L else w.id },
                    onDelete = { vm.deleteWord(w) },
                )
            }
        }
    }
}

@Composable
private fun ReviewCard(
    word: Word,
    flipped: Boolean,
    onFlip: () -> Unit,
    onRate: (Srs.Rating) -> Unit,
    onSkip: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onFlip() }) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(statusLabel(word.status()), style = MaterialTheme.typography.labelMedium)
            Text(word.hanzi, fontSize = 44.sp, textAlign = TextAlign.Center)
            if (flipped) {
                Text(word.pinyin, style = MaterialTheme.typography.titleMedium)
                Text(word.meaning, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                if (word.example.isNotEmpty()) {
                    Text(word.example, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                    Text(word.examplePinyin, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                    Text(word.exampleMeaning, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = { onRate(Srs.Rating.AGAIN) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                    ) { Text("ไม่ได้") }
                    Button(
                        onClick = { onRate(Srs.Rating.GOOD) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    ) { Text("จำได้") }
                    Button(
                        onClick = { onRate(Srs.Rating.KNOWN) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                    ) { Text("รู้แล้ว") }
                }
            } else {
                Text("แตะการ์ดเพื่อดูคำตอบ", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = onSkip) { Text("ข้าม") }
            }
        }
    }
}

@Composable
private fun WordRow(
    word: Word,
    expanded: Boolean,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().clickable { onToggle() }.padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${word.hanzi}  ${word.pinyin}", style = MaterialTheme.typography.bodyLarge)
                Text(word.meaning, style = MaterialTheme.typography.bodyMedium)
            }
            Text(statusLabel(word.status()), style = MaterialTheme.typography.labelMedium)
        }
        if (expanded) {
            if (word.example.isNotEmpty()) {
                Text(word.example, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 4.dp))
                Text(word.examplePinyin, style = MaterialTheme.typography.bodySmall)
                Text(word.exampleMeaning, style = MaterialTheme.typography.bodyMedium)
            }
            if (!word.isBuiltIn) {
                TextButton(onClick = onDelete) { Text("ลบคำนี้") }
            }
        }
    }
}

# HanziReminder

แอป Android สำหรับเรียน/ทบทวนภาษาจีน: แจ้งเตือนคำศัพท์ตามเวลาที่ตั้ง + วิดเจ็ตหน้าจอหลัก (คำศัพท์ประจำวัน, แตะพลิกดูคำตอบ, ปุ่มถัดไป)

## วิธีรัน
1. เปิดโฟลเดอร์นี้ด้วย Android Studio (Koala ขึ้นไป) แล้วรอ Gradle sync
2. รันบนเครื่องจริงหรือ emulator (Android 8.0 / API 26 ขึ้นไป)
3. อนุญาตการแจ้งเตือนเมื่อแอปถาม
4. กดค้างหน้าจอหลัก > Widgets > "คำศัพท์จีน"

## โครงสร้าง
- `data/` Room (ตาราง words), ชุดคำ HSK1 ในตัว, เวลาแจ้งเตือน (SharedPreferences)
- `reminder/` WorkManager ตั้งเตือนทุกวันตามเวลา + Notification
- `widget/` Jetpack Glance widget
- `MainActivity.kt` หน้าจอ Compose: ตั้งเวลา เพิ่ม/ลบคำศัพท์

## หมายเหตุ
- ยังไม่ได้คอมไพล์ทดสอบ (สร้างโดยไม่มี Android SDK) หาก sync/build แล้วมี error ส่งข้อความมาได้เลย
- WorkManager อาจเตือนคลาดเคลื่อนเล็กน้อยเมื่ออยู่ใน Doze mode
- ถ้าต้องการเวลาเป๊ะ เปลี่ยนไปใช้ AlarmManager (ต้องขอสิทธิ์ exact alarm)
